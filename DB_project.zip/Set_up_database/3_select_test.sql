-- Provinces Table
SELECT * FROM provinces;

-- Users Table
SELECT * FROM users;

-- Restaurants Table
SELECT * FROM restaurants;

-- Branches Table
SELECT * FROM branches;

-- Branch Locations Table
SELECT * FROM branch_locations;

-- Branch Tables Table
SELECT * FROM branch_tables;

-- Food Limitation Table
SELECT * FROM food_limitations;

-- Menus Table
SELECT * FROM menus;

-- Timeslots Table
SELECT * FROM timeslots;

-- Search Records Table
SELECT * FROM search_records;

-- Reserves Table
SELECT * FROM reserves;

-- Restaurant Managers Table
SELECT * FROM restaurant_managers;

-- Admins Table
SELECT * FROM admins;

-- Reports Table
SELECT * FROM reports;

-- Logs Table
SELECT * FROM logs;